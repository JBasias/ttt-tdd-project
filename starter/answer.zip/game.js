
const TTT = require("./class/ttt");

ttt = new TTT();


